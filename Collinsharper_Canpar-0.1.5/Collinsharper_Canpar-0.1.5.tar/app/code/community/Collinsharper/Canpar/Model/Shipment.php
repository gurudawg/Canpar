<?php
/**
 * Created by Gayan Hewa
 * User: Gayan
 * Date: 9/15/13
 * Time: 9:15 PM
 */

class Collinsharper_Canpar_Model_Shipment extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('canparmodule/shipment');
    }
}