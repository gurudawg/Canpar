<?php
/**
 * Created by Gayan Hewa
 * User: Gayan
 * Date: 7/17/13
 * Time: 7:04 PM
 */

class Collinsharper_Canpar_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * Get current customer session
     *
     * @return Object
     */
    public function getSession()
    {
        return Mage::getSingleton('customer/session');
    }

    /**
     * Get config value for the module
     *
     * @param String $key Configuration key
     *
     * @return type
     */
    public function getConfig($key)
    {
        return Mage::getStoreConfig('carriers/canparmodule/' . $key);
    }

    public function getConfigFlag($key)
    {
        return Mage::getStoreConfigFlag('carriers/canparmodule/' . $key);
    }
    /**
     * Is debugging enabled
     *
     * @return boolean
     */
    public function isDebug()
    {
        return $this->getConfig('debug') == 1;
    }

    /**
     * Get Shipping Method object
     *
     * @return Object
     */
    public function getShippingModule()
    {
        return Mage::getSingleton('canparmodule/carrier_shippingmethod');
    }

    /**
     * Convert Special characters to API acceptable format.
     *
     * @param String $txt text with special characters
     *
     * @return String
     */
    public function sanitize($txt)
    {
        $transliterationTable = array('á' => 'a', 'Á' => 'A', 'à' => 'a', 'À' => 'A', 'ă' => 'a', 'Ă' => 'A', 'â' => 'a', 'Â' => 'A', 'å' => 'a', 'Å' => 'A', 'ã' => 'a', 'Ã' => 'A', 'ą' => 'a', 'Ą' => 'A', 'ā' => 'a', 'Ā' => 'A', 'ä' => 'ae', 'Ä' => 'AE', 'æ' => 'ae', 'Æ' => 'AE', 'ḃ' => 'b', 'Ḃ' => 'B', 'ć' => 'c', 'Ć' => 'C', 'ĉ' => 'c', 'Ĉ' => 'C', 'č' => 'c', 'Č' => 'C', 'ċ' => 'c', 'Ċ' => 'C', 'ç' => 'c', 'Ç' => 'C', 'ď' => 'd', 'Ď' => 'D', 'ḋ' => 'd', 'Ḋ' => 'D', 'đ' => 'd', 'Đ' => 'D', 'ð' => 'dh', 'Ð' => 'Dh', 'é' => 'e', 'É' => 'E', 'è' => 'e', 'È' => 'E', 'ĕ' => 'e', 'Ĕ' => 'E', 'ê' => 'e', 'Ê' => 'E', 'ě' => 'e', 'Ě' => 'E', 'ë' => 'e', 'Ë' => 'E', 'ė' => 'e', 'Ė' => 'E', 'ę' => 'e', 'Ę' => 'E', 'ē' => 'e', 'Ē' => 'E', 'ḟ' => 'f', 'Ḟ' => 'F', 'ƒ' => 'f', 'Ƒ' => 'F', 'ğ' => 'g', 'Ğ' => 'G', 'ĝ' => 'g', 'Ĝ' => 'G', 'ġ' => 'g', 'Ġ' => 'G', 'ģ' => 'g', 'Ģ' => 'G', 'ĥ' => 'h', 'Ĥ' => 'H', 'ħ' => 'h', 'Ħ' => 'H', 'í' => 'i', 'Í' => 'I', 'ì' => 'i', 'Ì' => 'I', 'î' => 'i', 'Î' => 'I', 'ï' => 'i', 'Ï' => 'I', 'ĩ' => 'i', 'Ĩ' => 'I', 'į' => 'i', 'Į' => 'I', 'ī' => 'i', 'Ī' => 'I', 'ĵ' => 'j', 'Ĵ' => 'J', 'ķ' => 'k', 'Ķ' => 'K', 'ĺ' => 'l', 'Ĺ' => 'L', 'ľ' => 'l', 'Ľ' => 'L', 'ļ' => 'l', 'Ļ' => 'L', 'ł' => 'l', 'Ł' => 'L', 'ṁ' => 'm', 'Ṁ' => 'M', 'ń' => 'n', 'Ń' => 'N', 'ň' => 'n', 'Ň' => 'N', 'ñ' => 'n', 'Ñ' => 'N', 'ņ' => 'n', 'Ņ' => 'N', 'ó' => 'o', 'Ó' => 'O', 'ò' => 'o', 'Ò' => 'O', 'ô' => 'o', 'Ô' => 'O', 'ő' => 'o', 'Ő' => 'O', 'õ' => 'o', 'Õ' => 'O', 'ø' => 'oe', 'Ø' => 'OE', 'ō' => 'o', 'Ō' => 'O', 'ơ' => 'o', 'Ơ' => 'O', 'ö' => 'oe', 'Ö' => 'OE', 'ṗ' => 'p', 'Ṗ' => 'P', 'ŕ' => 'r', 'Ŕ' => 'R', 'ř' => 'r', 'Ř' => 'R', 'ŗ' => 'r', 'Ŗ' => 'R', 'ś' => 's', 'Ś' => 'S', 'ŝ' => 's', 'Ŝ' => 'S', 'š' => 's', 'Š' => 'S', 'ṡ' => 's', 'Ṡ' => 'S', 'ş' => 's', 'Ş' => 'S', 'ș' => 's', 'Ș' => 'S', 'ß' => 'SS', 'ť' => 't', 'Ť' => 'T', 'ṫ' => 't', 'Ṫ' => 'T', 'ţ' => 't', 'Ţ' => 'T', 'ț' => 't', 'Ț' => 'T', 'ŧ' => 't', 'Ŧ' => 'T', 'ú' => 'u', 'Ú' => 'U', 'ù' => 'u', 'Ù' => 'U', 'ŭ' => 'u', 'Ŭ' => 'U', 'û' => 'u', 'Û' => 'U', 'ů' => 'u', 'Ů' => 'U', 'ű' => 'u', 'Ű' => 'U', 'ũ' => 'u', 'Ũ' => 'U', 'ų' => 'u', 'Ų' => 'U', 'ū' => 'u', 'Ū' => 'U', 'ư' => 'u', 'Ư' => 'U', 'ü' => 'ue', 'Ü' => 'UE', 'ẃ' => 'w', 'Ẃ' => 'W', 'ẁ' => 'w', 'Ẁ' => 'W', 'ŵ' => 'w', 'Ŵ' => 'W', 'ẅ' => 'w', 'Ẅ' => 'W', 'ý' => 'y', 'Ý' => 'Y', 'ỳ' => 'y', 'Ỳ' => 'Y', 'ŷ' => 'y', 'Ŷ' => 'Y', 'ÿ' => 'y', 'Ÿ' => 'Y', 'ź' => 'z', 'Ź' => 'Z', 'ž' => 'z', 'Ž' => 'Z', 'ż' => 'z', 'Ż' => 'Z', 'þ' => 'th', 'Þ' => 'Th', 'µ' => 'u', 'а' => 'a', 'А' => 'a', 'б' => 'b', 'Б' => 'b', 'в' => 'v', 'В' => 'v', 'г' => 'g', 'Г' => 'g', 'д' => 'd', 'Д' => 'd', 'е' => 'e', 'Е' => 'e', 'ё' => 'e', 'Ё' => 'e', 'ж' => 'zh', 'Ж' => 'zh', 'з' => 'z', 'З' => 'z', 'и' => 'i', 'И' => 'i', 'й' => 'j', 'Й' => 'j', 'к' => 'k', 'К' => 'k', 'л' => 'l', 'Л' => 'l', 'м' => 'm', 'М' => 'm', 'н' => 'n', 'Н' => 'n', 'о' => 'o', 'О' => 'o', 'п' => 'p', 'П' => 'p', 'р' => 'r', 'Р' => 'r', 'с' => 's', 'С' => 's', 'т' => 't', 'Т' => 't', 'у' => 'u', 'У' => 'u', 'ф' => 'f', 'Ф' => 'f', 'х' => 'h', 'Х' => 'h', 'ц' => 'c', 'Ц' => 'c', 'ч' => 'ch', 'Ч' => 'ch', 'ш' => 'sh', 'Ш' => 'sh', 'щ' => 'sch', 'Щ' => 'sch', 'ъ' => '', 'Ъ' => '', 'ы' => 'y', 'Ы' => 'y', 'ь' => '', 'Ь' => '', 'э' => 'e', 'Э' => 'e', 'ю' => 'ju', 'Ю' => 'ju', 'я' => 'ja', 'Я' => 'ja');
        $txt = str_replace(array_keys($transliterationTable), array_values($transliterationTable), $txt);
        return $txt;
    }

    /**
     *  Logging
     */
    public function log($message)
    {
        $file = "canpar.log";

        if (Mage::getStoreConfig('carriers/canparmodule/debug')) {
            Mage::log($message, "1", $file);
        }
    }

    /*
     *  Get API Soapclient
     */
    public function getClient($type)
    {
        $soapInterface = new Collinsharper_Canpar_Model_Soapinterface();
        return $soapInterface->getClient($type);
    }

    /*
     *  Trim
     */
    public function chop($string, $start, $end)
    {
        if (strlen($string) > 0){
            return substr($string, $start, $end);
        }
        return "";
    }

    /*
     *  Strip all spaces  plus whitespaces
     */
    public function strip($string)
    {
        $string = preg_replace('/\s+/', '', $string);

        return $string;
    }

    public function getQuote()
    {
        if (Mage::app()->getStore()->isAdmin()) {
            $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();
        } else {
            $quote = Mage::getSingleton('checkout/session')->getQuote();
            if ($quote->getId()) {
                $quote = Mage::getModel('sales/quote')->load($quote->getId());
            }
        }
        return $quote;
    }

    public function getPackageWeightLb($_quote = false)
    {

        if(!$_quote) {
            $_quote = $this->getQuote();
        }

        $weight = 0;
        $chunit = Mage::helper('chunit');
        $default_weight_unit = Mage::getStoreConfig('catalog/measure_units/weight');
        $default_dim_unit = Mage::getStoreConfig('catalog/measure_units/length');
        $weight_unit = $this->getConfig('default_weight_unit');

        foreach ($_quote->getAllItems() as $item) {
            $qty = ($item->getQty() * 1);
            $product = Mage::getModel('catalog/product')->load($item->getProductId());
            $weight += $chunit->getConvertedWeight(($qty * $product->getWeight()), $default_weight_unit, strtolower($weight_unit));

        }

        return $weight;
    }

    protected function getConvertedWeight($w, $u)
    {

        $weight = $w;
        switch ($u) {
            case 'lb':
                $weight = round($w * 0.4535, 2);
                break;
            case 'gr':
                $weight = round($w * 0.001, 2);
                break;
            case 'oz':
                $weight = round($w * 0.028349, 2);
                break;
            case 'kg':
            default:
                $weight = $w;
                break;
        }

        return $weight;
    }
}
